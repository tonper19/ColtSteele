stdnum.md.idno
==============

.. automodule:: stdnum.md.idno
   :members: