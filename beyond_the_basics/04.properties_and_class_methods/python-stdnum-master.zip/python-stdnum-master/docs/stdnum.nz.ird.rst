stdnum.nz.ird
=============

.. automodule:: stdnum.nz.ird
   :members: