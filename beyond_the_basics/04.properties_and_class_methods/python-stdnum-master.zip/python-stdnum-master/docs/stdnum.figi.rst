stdnum.figi
===========

.. automodule:: stdnum.figi
   :members: