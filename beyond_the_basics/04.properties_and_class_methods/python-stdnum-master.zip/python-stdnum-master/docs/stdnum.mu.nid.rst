stdnum.mu.nid
=============

.. automodule:: stdnum.mu.nid
   :members: