stdnum.no.fodselsnummer
=======================

.. automodule:: stdnum.no.fodselsnummer
   :members: