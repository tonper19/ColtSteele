stdnum.pt.nif
=============

.. automodule:: stdnum.pt.nif
   :members:
