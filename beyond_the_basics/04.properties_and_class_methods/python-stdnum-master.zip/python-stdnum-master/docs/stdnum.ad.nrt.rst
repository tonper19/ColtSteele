stdnum.ad.nrt
=============

.. automodule:: stdnum.ad.nrt
   :members: