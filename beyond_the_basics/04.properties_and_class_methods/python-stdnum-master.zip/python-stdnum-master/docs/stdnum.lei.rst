stdnum.lei
==========

.. automodule:: stdnum.lei
   :members: