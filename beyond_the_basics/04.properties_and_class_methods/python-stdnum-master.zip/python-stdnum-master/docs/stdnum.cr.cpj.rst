stdnum.cr.cpj
=============

.. automodule:: stdnum.cr.cpj
   :members: