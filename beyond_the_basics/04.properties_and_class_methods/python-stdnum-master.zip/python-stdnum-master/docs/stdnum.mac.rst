stdnum.mac
==========

.. automodule:: stdnum.mac
   :members: