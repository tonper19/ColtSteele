stdnum.uy.rut
=============

.. automodule:: stdnum.uy.rut
   :members: