stdnum.ch.uid
=============

.. automodule:: stdnum.ch.uid
   :members: