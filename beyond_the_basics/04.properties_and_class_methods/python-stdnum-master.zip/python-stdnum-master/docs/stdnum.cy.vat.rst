stdnum.cy.vat
=============

.. automodule:: stdnum.cy.vat
   :members:
