stdnum.de.wkn
=============

.. automodule:: stdnum.de.wkn
   :members: