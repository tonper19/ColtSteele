stdnum.no.iban
==============

.. automodule:: stdnum.no.iban
   :members: