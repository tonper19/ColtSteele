stdnum.es.cups
==============

.. automodule:: stdnum.es.cups
   :members: