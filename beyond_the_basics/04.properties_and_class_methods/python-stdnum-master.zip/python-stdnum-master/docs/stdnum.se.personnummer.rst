stdnum.se.personnummer
======================

.. automodule:: stdnum.se.personnummer
   :members: