stdnum.iso11649
===============

.. automodule:: stdnum.iso11649
   :members: