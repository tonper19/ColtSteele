stdnum.co.nit
=============

.. automodule:: stdnum.co.nit
   :members: