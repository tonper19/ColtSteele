stdnum.at.vnr
=============

.. automodule:: stdnum.at.vnr
   :members: