stdnum.pe.cui
=============

.. automodule:: stdnum.pe.cui
   :members: