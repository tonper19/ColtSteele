stdnum.cr.cpf
=============

.. automodule:: stdnum.cr.cpf
   :members: