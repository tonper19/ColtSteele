stdnum.lt.asmens
================

.. automodule:: stdnum.lt.asmens
   :members: