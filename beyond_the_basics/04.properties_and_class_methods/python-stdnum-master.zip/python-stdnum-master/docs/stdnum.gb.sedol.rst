stdnum.gb.sedol
===============

.. automodule:: stdnum.gb.sedol
   :members: