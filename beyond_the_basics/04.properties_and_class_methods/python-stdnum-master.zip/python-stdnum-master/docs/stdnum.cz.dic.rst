stdnum.cz.dic
=============

.. automodule:: stdnum.cz.dic
   :members:
