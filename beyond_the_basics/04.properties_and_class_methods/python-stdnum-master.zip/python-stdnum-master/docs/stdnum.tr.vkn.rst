stdnum.tr.vkn
=============

.. automodule:: stdnum.tr.vkn
   :members: