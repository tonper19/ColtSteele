stdnum.pe.ruc
=============

.. automodule:: stdnum.pe.ruc
   :members: