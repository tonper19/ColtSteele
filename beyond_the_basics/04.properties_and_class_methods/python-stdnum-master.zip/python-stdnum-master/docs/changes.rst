Changes in python-stdnum
========================

.. include:: ../NEWS
