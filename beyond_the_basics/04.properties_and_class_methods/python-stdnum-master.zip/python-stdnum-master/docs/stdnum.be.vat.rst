stdnum.be.vat
=============

.. automodule:: stdnum.be.vat
   :members:
