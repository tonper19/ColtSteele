stdnum.isil
===========

.. automodule:: stdnum.isil
   :members:
