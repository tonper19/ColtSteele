stdnum.mx.curp
==============

.. automodule:: stdnum.mx.curp
   :members: