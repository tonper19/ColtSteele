stdnum.no.kontonr
=================

.. automodule:: stdnum.no.kontonr
   :members: