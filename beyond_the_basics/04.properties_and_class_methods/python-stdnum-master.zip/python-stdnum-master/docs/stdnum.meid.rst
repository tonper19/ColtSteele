stdnum.meid
===========

.. automodule:: stdnum.meid
   :members:
