stdnum.cr.cr
============

.. automodule:: stdnum.cr.cr
   :members: