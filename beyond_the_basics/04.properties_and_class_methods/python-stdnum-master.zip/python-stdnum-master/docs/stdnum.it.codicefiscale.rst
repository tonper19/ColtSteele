stdnum.it.codicefiscale
=======================

.. automodule:: stdnum.it.codicefiscale
   :members:
