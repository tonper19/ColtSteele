{{ fullname }}
{{ underline }}

.. automodule:: {{ fullname }}
   :members:
