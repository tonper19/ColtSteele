stdnum.issn
===========

.. automodule:: stdnum.issn
   :members:
