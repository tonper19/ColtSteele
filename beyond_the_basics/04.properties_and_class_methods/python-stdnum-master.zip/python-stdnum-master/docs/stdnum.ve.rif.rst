stdnum.ve.rif
=============

.. automodule:: stdnum.ve.rif
   :members: