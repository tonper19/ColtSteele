stdnum.de.stnr
==============

.. automodule:: stdnum.de.stnr
   :members: