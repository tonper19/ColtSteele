stdnum.py.ruc
=============

.. automodule:: stdnum.py.ruc
   :members: