stdnum.de.idnr
==============

.. automodule:: stdnum.de.idnr
   :members: